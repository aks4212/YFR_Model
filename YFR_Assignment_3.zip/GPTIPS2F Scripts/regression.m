clear;
close all;
clc

addpath(genpath('E:\New folder (2)\gptips2')); 

gp = rungp(@config_ethane);
%popbrowser(gp);

try
    plotpareto(gp); 
catch
    popbrowser(gp); 
end
title('Pareto Front: Accuracy v/s Complexity for Ethane \xi');

summary(gp);

function gp = config_ethane(gp)
opts = detectImportOptions('Ethane_sat.csv','VariableNamingRule','preserve');
data = readtable('Ethane_sat.csv',opts);

T = data.('T (K)');
rho_liq = data.('rho_liq (kg/m3)');
rho_vap = data.('rho_vap (kg/m3)');

Tc = 305.32;
rhoc = 206.18;

Tr = T./Tc;
xi = (rho_liq - rho_vap)./rhoc;

gp.userdata.xtrain = Tr(:);
gp.userdata.ytrain = xi(:);

gp.nodes.inputs.names = {'Tr'};
gp.nodes.inputs.num_inp = 1;

gp.nodes.functions.name = {'plus', 'minus', 'times', 'sqrt', 'square', 'thermofun'};
gp.nodes.functions.arity = [2, 2, 2, 1, 1, 1];

gp.runcontrol.pop_size = 200;
gp.runcontrol.num_gen = 100;

gp.genes.max_genes = 4;
gp.genes.multigene = true;

gp.opts.pareto = 1;

end


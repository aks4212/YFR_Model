function y = thermofun(x)
y = 1 - x;
end
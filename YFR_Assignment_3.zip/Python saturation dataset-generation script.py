import numpy as np
import pandas as pd
import CoolProp.CoolProp as CP
import os

output_dir = 'Fluid_saturation_CSVs'
if not os.path.exists(output_dir):
   os.makedirs(output_dir)

fluids = CP.get_global_param_string("FluidsList").split(',')

valid_fluids = []
for fluid in fluids:
  if len(valid_fluids) >= 50:
    break
  try:
    CP.PropsSI('T_critical', fluid)
    valid_fluids.append(fluid)
  except:
    continue
 

master_list = []
total_removed = {"total_attempted": 0, "removed_nans": 0, "removed_non_monotonic": 0, "removed_negatives": 0}

for fluid in valid_fluids:
  try:
    backend_fluid = f"HEOS::{fluid}"

    T_triple = CP.PropsSI('Tmin', backend_fluid)
    T_crit = CP.PropsSI('T_critical', backend_fluid)

    T_grid = np.linspace(T_triple + 2, T_crit - 2, 100)

    fluid_results = []
    last_P = -1

    for T in T_grid:
      total_removed['total_attempted'] += 1
      try:
        psat = CP.PropsSI('P', 'T', T, 'Q', 0, backend_fluid)
        rholiq = CP.PropsSI('D', 'T', T, 'Q', 0, backend_fluid)
        rhovap = CP.PropsSI('D', 'T', T, 'Q', 1, backend_fluid)

        if np.isnan(psat) or np.isnan(rholiq) or np.isnan(rhovap):
           total_removed['removed_nans'] += 1
           continue
        
        if psat <= last_P:
           total_removed['removed_non_monotonic'] += 1
           continue
        
        if psat <= 0 or rholiq <= 0 or rhovap <= 0:
                    total_removed['romoved_negatives'] += 1
                    continue
        
        row = [fluid, T, psat, rholiq, rhovap]
        fluid_results.append(row)
        master_list.append(row)
        last_P = psat

      except:
        total_removed['removed_nans'] += 1
        continue

    if fluid_results:
       df_ind = pd.DataFrame(fluid_results, columns=['Fluid', 'T (K)', 'p_sat (Pa)', 'rho_liq (kg/m3)', 'rho_vap (kg/m3)']) 
       df_ind = df_ind.sort_values(by='T (K)')
       df_ind.to_csv(f'{output_dir}/{fluid}_sat.csv', index=False) 

  except Exception as e:
    continue 

df_master = pd.DataFrame(master_list, columns=['Fluid', 'T (K)', 'p_sat (Pa)', 'rho_liq (Kg/m3)', 'rho_vap (kg/m3)'])
df_master = df_master.sort_values(by=['Fluid', 'T (K)'])
df_master.to_csv('Master_saturation_Dataset.csv', index=False) 

print(f"Cleaning Results:")
print(f"- Non-monotonic removed: {total_removed['removed_non_monotonic']}")
print(f"- NaNs/Convergence errors: {total_removed['removed_nans']}")
print(f"- Negatives removed: {total_removed['removed_negatives']}")